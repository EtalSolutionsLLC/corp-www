(function () {
  "use strict";

  var enhancedClass = "policy-modal-close-enhanced";
  var candidateSelector = 'button, [role="button"], a';
  var policyContainerSelector = [
    '[role="dialog"]',
    '[aria-modal="true"]',
    '[data-policy-modal-dialog]',
    '[data-policy-modal]',
    '[class*="policy"]',
    '[id*="policy"]'
  ].join(', ');

  function text(value) {
    return String(value || "").trim().toLowerCase();
  }

  function identity(element) {
    if (!element) return "";
    return [
      element.id,
      element.className,
      element.getAttribute && element.getAttribute("aria-label"),
      element.getAttribute && element.getAttribute("title"),
      element.getAttribute && element.getAttribute("data-policy-modal-close"),
      element.textContent
    ].map(text).join(" ");
  }

  function isCloseControl(element) {
    if (!element || !element.matches || !element.matches(candidateSelector)) return false;
    var value = identity(element);
    return value.indexOf("close") !== -1 || value === "×" || value === "x";
  }

  function isPolicyCloseControl(element) {
    if (!isCloseControl(element)) return false;

    var ownIdentity = identity(element);
    if (ownIdentity.indexOf("policy") !== -1 || ownIdentity.indexOf("privacy") !== -1) {
      return true;
    }

    if (!element.closest) return false;
    var container = element.closest(policyContainerSelector);
    if (!container) return false;

    var containerIdentity = identity(container);
    return containerIdentity.indexOf("policy") !== -1 || containerIdentity.indexOf("privacy") !== -1;
  }

  function enhance(element) {
    if (!isPolicyCloseControl(element)) return;
    element.classList.add("catalog-detail-close", enhancedClass);
    element.setAttribute("data-policy-modal-close-enhanced", "");
    element.setAttribute("aria-label", "Close privacy policy");
    element.textContent = "Close ×";
  }

  function upgrade(root) {
    var scope = root && root.querySelectorAll ? root : document;
    if (scope.matches && scope.matches(candidateSelector)) enhance(scope);
    scope.querySelectorAll(candidateSelector).forEach(enhance);
  }

  document.addEventListener("DOMContentLoaded", function () {
    upgrade(document);
    if (!document.body || typeof MutationObserver !== "function") return;

    new MutationObserver(function (records) {
      records.forEach(function (record) {
        if (record.type === "attributes") {
          upgrade(record.target);
          return;
        }

        record.addedNodes.forEach(function (node) {
          if (node.nodeType !== 1) return;
          upgrade(node);
        });
      });
    }).observe(document.body, {
      attributes: true,
      attributeFilter: ["class", "aria-label", "title", "data-policy-modal-close"],
      childList: true,
      subtree: true
    });
  });
}());
