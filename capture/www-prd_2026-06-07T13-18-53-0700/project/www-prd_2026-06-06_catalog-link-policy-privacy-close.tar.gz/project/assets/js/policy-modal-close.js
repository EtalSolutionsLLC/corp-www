(function () {
  "use strict";

  var enhancedClass = "policy-modal-close-enhanced";

  function text(value) {
    return String(value || "").trim().toLowerCase();
  }

  function isPrivacyDialog(element) {
    if (!element || !element.closest) return false;
    var dialog = element.closest('[role="dialog"], [aria-modal="true"], [class*="policy-modal"], [data-policy-modal-dialog]');
    if (!dialog) return false;
    var identity = [
      dialog.id,
      dialog.className,
      dialog.getAttribute("aria-label"),
      dialog.getAttribute("aria-labelledby"),
      dialog.textContent
    ].map(text).join(" ");
    return identity.indexOf("privacy") !== -1 || identity.indexOf("policy") !== -1;
  }

  function isCloseControl(button) {
    if (!button || button.tagName !== "BUTTON") return false;
    var identity = [
      button.className,
      button.getAttribute("aria-label"),
      button.getAttribute("title"),
      button.textContent
    ].map(text).join(" ");
    return identity.indexOf("close") !== -1 || identity === "×" || identity === "x";
  }

  function upgrade(root) {
    var scope = root && root.querySelectorAll ? root : document;
    scope.querySelectorAll("button").forEach(function (button) {
      if (!isCloseControl(button) || !isPrivacyDialog(button)) return;
      button.classList.add("catalog-detail-close", enhancedClass);
      button.setAttribute("aria-label", "Close privacy policy");
      button.textContent = "Close ×";
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    upgrade(document);
    if (!document.body || typeof MutationObserver !== "function") return;
    new MutationObserver(function (records) {
      records.forEach(function (record) {
        record.addedNodes.forEach(function (node) {
          if (node.nodeType !== 1) return;
          upgrade(node);
          if (node.matches && node.matches("button")) upgrade(node.parentElement || node);
        });
      });
    }).observe(document.body, { childList: true, subtree: true });
  });
}());
